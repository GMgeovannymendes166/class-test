import java.util.Random;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//////////////////////
        i.
                    public static void main(String[] args) {
                    String[] strArr = new String[50];
                }
                }

        ii.
                    public static void main(String[] args) {
                    String[] strArr;
                    strArr = new String[50];

                    }

        iii.

                   for (int i = 0; < strArr.length;
                   strArr[i] ="\\";
                   }

        iv.

                   for (int i = strArr.length - 1; i >= 0; i--) {
                        System.out.println(i + ":" + strArr[i]);



        v.
        import java.util.Arrays;
        import java.util.Random;

        Random rand  = new Random();
        int[] intArr = new int[50];
        for (int i = 0; i < intArr.length;
             intArr[i] = rand.nextInt(50);
        }

        Arrays.sort(intArr);


        vi.
                int[][] int[5][8];

        vii.

        int[][ intArr;
        intArr = new int[5][8];

        viii.

        int[][] intArr;
        intArr = new int[5][]
        for (int i = 0; i < intArr.length;
             intArr[i] = new int[8];

        ix.

        for (int i = 0; i < intARR.LEMGTH;
             for (int j = 0; j < intArr[i]).length; j++) {
            intArr[i][j] = i * j;
        }





